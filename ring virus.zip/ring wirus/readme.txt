run file "ring.bat" as administrator or it doesn't work
